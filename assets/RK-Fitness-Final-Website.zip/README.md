# RK FITNESS — STATIC WEBSITE EDITION

A luxury, minimal, monochromatic athletic club website rebuilt from scratch with **frosted glassmorphism**, **real RK Fitness facility photography**, **UI/UX Pro Max standards**, and **21st.dev MCP component architectures**.

---

## 🏛️ Project Architecture

```
rk-fitness/
├── index.html                   # Semantic HTML5 static single-page experience
├── css/
│   ├── design-tokens.css        # Monochromatic B&W design tokens (colors, spacing, typography)
│   ├── glassmorphism.css        # Sophisticated frosted glass surfaces & reflections
│   └── style.css                # Responsive layout, grid, components, and accessibility
├── js/
│   └── main.js                  # Accessible nav, modal dialogs, and gallery lightbox
├── assets/
│   ├── logos/
│   │   ├── Gym_logo.jpg         # Genuine RK Fitness official emblem
│   │   └── rk-fitness-logo.jpg  # Normalized reference
│   └── images/                  # Genuine facility, free weights, turf & cardio photography
└── design-system/
    └── rk-fitness/
        └── MASTER.md            # Design system source of truth
```

---

## 🎯 Design Directives Satisfied

1. **Strict Black & White Palette**:
   - Monochromatic contrast hierarchy (pitch black, graphite, off-white, crisp white).
   - Zero extraneous neon, gold, red, blue, green, or orange colors.
2. **Frosted Glassmorphism**:
   - High-end backdrop blur (`backdrop-filter: blur(16px)`), subtle borders (`rgba(255,255,255,0.08)`), top specular highlights (`inset 0 1px 0 0 rgba(255,255,255,0.15)`).
3. **Genuine RK Fitness Photography**:
   - 100% authentic images from the gym floor (`hero-facility.webp`, `free-weights-hall.webp`, `cardio-deck.webp`, `functional-turf.webp`, `strength-arena.webp`, `dumbbell-zone.webp`, etc.).
   - Zero stock imagery or AI-generated people.
4. **No Fabricated Information**:
   - Real, verified gym offerings (Free Weights, Cardio, Plate-loaded circuits, Functional turf, 1-on-1 coaching).
   - No fake claims, fake trainer bios, fake testimonials, or fake prices.
5. **Accessibility & Responsiveness**:
   - WCAG 2.2 AA compliant contrast (>4.5:1 for body copy, >7:1 for headings).
   - Keyboard accessible navigation, focus rings (`outline: 2px solid #ffffff`), and ARIA modal support.
   - Fluid responsiveness across 375px mobile, tablet, laptop, and 4K desktop screens.

---

## 🚀 Running Locally

Open `index.html` in any browser or launch a static server:
```bash
python3 -m http.server 8080 --directory .
```
Navigate to `http://localhost:8080`.
