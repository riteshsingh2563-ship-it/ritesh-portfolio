# RK FITNESS — DESIGN SYSTEM MASTER (SOURCE OF TRUTH)

## 1. Brand Identity & Creative Direction
- **Brand**: RK Fitness
- **Style Concept**: High-End Monochromatic Athletic Club + Minimal Editorial Layout + Frosted Glassmorphism
- **Design Persona**: Disciplined, athletic, high-contrast, premium, architectural
- **Core Principle**: Contrast over color. Form follows athletic purpose.

---

## 2. Color System (Strict Monochromatic)
| Role | Hex / Value | Semantic Variable | Usage |
|------|-------------|-------------------|-------|
| Deep Background | `#050507` | `--color-black-deep` | Footer, deep backdrops |
| Base Background | `#0a0a0d` | `--color-black-base` | Main body background |
| Surface Background | `#101015` | `--color-black-surface` | Section backgrounds, card foundations |
| Card Surface | `#16161d` | `--color-black-elevated` | Secondary cards |
| Subtle Border | `rgba(255,255,255,0.07)` | `--glass-border-subtle` | Passive dividers |
| Medium Border | `rgba(255,255,255,0.13)` | `--glass-border-medium` | Card & panel outlines |
| Bright Border | `rgba(255,255,255,0.28)` | `--glass-border-bright` | Active states, hover, primary outlines |
| Primary Text | `#ffffff` | `--text-primary` | Headings, hero display, primary labels |
| Secondary Text | `#f3f3f6` | `--text-secondary` | Lead paragraphs, card titles |
| Muted Text | `#9e9ea9` | `--text-muted` | Body text, captions (>4.5:1 on dark) |
| Primary CTA | `#ffffff` / text `#000000` | `--cta-bg` / `--cta-fg` | High-contrast conversion actions |

> **Strict Rule**: Zero neon accents, zero oranges, reds, blues, golds, or rainbow gradients. Monochromatic contrast drives all hierarchy.

---

## 3. Glassmorphism Architecture
- **Navigation**: `rgba(10, 10, 13, 0.85)` with `backdrop-filter: blur(16px)` and 1px border.
- **Panels & Cards**: `rgba(18, 18, 24, 0.72)` with `backdrop-filter: blur(16px)` and `inset 0 1px 0 0 rgba(255,255,255,0.15)`.
- **Modals**: `rgba(12, 12, 16, 0.94)` with `backdrop-filter: blur(24px)`.
- **Badges / Tags**: `rgba(255, 255, 255, 0.06)` with 1px border and pill shape.

---

## 4. Typography Hierarchy
- **Display Headings**: `'Barlow Condensed', sans-serif`
  - H1: `clamp(2.75rem, 6vw, 4.75rem)` (Weight: 800, uppercase, letter-spacing: 0.02em)
  - H2: `clamp(2.25rem, 4.5vw, 3.5rem)` (Weight: 700, uppercase, letter-spacing: 0.03em)
  - H3: `clamp(1.4rem, 2.5vw, 1.85rem)` (Weight: 700, uppercase)
  - Badges / Subtitles: Weight: 600, tracking: 0.15em - 0.22em uppercase
- **Body Text**: `'Barlow', sans-serif`
  - Lead: `clamp(1.05rem, 1.8vw, 1.25rem)` (Line height: 1.6)
  - Body: `1rem` (Line height: 1.65, letter-spacing: 0.01em)
  - Micro / Tags: `0.8rem` - `0.875rem`

---

## 5. Photographic & Asset Treatment
- **Authenticity**: Exclusively real RK Fitness photographs from the facility repository (`assets/images/`).
- **Grading**: Subtle high-contrast monochromatic treatment (`grayscale(100%) contrast(110-115%)`) that preserves natural depth, floor reflections, and equipment details.
- **Composition**: Asymmetric Bento Grid, full-bleed hero backdrop with radial dark scrim, and zone cards with dark bottom gradients.

---

## 6. Layout & Spacing Rhythm (8px Base)
- `4px` / `8px` / `12px` / `16px` / `24px` / `32px` / `48px` / `64px` / `96px`
- Section Padding: `clamp(4.5rem, 8vw, 7.5rem)` vertical
- Container Maximum Width: `1280px`
- Breakpoints: `375px` (mobile), `768px` (tablet), `1024px` (desktop), `1280px` (wide)

---

## 7. Accessibility & Performance Rules
- All text passes WCAG 2.2 AA (minimum 4.5:1 contrast against dark glass).
- Visible keyboard focus indicators (`outline: 2px solid #ffffff; outline-offset: 3px`).
- ARIA landmarks (`header`, `main`, `footer`, `nav`, `section[aria-labelledby]`).
- Modal accessibility with focus trap, `aria-modal="true"`, and Escape key dismissal.
- Full respect for `@media (prefers-reduced-motion: reduce)`.
- Zero external tracking scripts, zero heavy frameworks, zero runtime layout shift.
